# Car Daily Income

Simple Android app for car income and expense tracking.

## Accounts
- Admin: `admin` / `1234`
- Partner (view only): `partner` / `1234`

## Features
Name, Car Number, Car Model, City, Income, Daily Income, Monthly Earning, Kharcha.
Admin can add/edit/delete. Partner can only monitor/view.
Data is stored locally on the phone.

## Build
Open this folder in Android Studio and build an APK.
The project uses Android Gradle Plugin 8.5.2, compileSdk 35, Java, and AndroidX.
